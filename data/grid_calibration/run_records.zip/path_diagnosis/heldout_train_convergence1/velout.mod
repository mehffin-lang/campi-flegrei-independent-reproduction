Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.22       -0.50    1.000
 2.69        1.00    1.000
 4.29        3.00    1.000
 5.59        5.00  100.000
4
 1.50       -0.50    1.000
 2.12        1.00    1.000
 3.44        3.00    1.000
 3.76        5.00  100.000
