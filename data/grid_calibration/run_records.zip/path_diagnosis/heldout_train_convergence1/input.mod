Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.33       -0.50    1.000
 2.84        1.00    1.000
 4.64        3.00    1.000
 5.59        5.00  100.000
4
 1.29       -0.50    1.000
 2.14        1.00    1.000
 3.63        3.00    1.000
 3.76        5.00  100.000
