Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.27       -0.50    1.000
 2.64        1.00    1.000
 4.22        3.00    1.000
 5.59        5.00  100.000
4
 1.55       -0.50    1.000
 2.10        1.00    1.000
 3.43        3.00    1.000
 3.76        5.00  100.000
