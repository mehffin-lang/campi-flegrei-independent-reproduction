Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.37       -0.50    1.000
 3.42        1.00    1.000
 5.03        3.00    1.000
 5.59        5.00  100.000
4
 1.03       -0.50    1.000
 2.15        1.00    1.000
 3.68        3.00    1.000
 3.74        5.00  100.000
