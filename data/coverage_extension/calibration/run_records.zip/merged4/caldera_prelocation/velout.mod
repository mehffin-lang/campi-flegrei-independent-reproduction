Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.64       -0.50    1.000
 3.83        1.00    1.000
 5.12        3.00    1.000
 5.59        5.00  100.000
4
 1.43       -0.50    1.000
 2.13        1.00    1.000
 3.04        3.00    1.000
 3.36        5.00  100.000
