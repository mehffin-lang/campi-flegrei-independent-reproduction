Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.14       -0.50    1.000
 2.73        1.00    1.000
 4.20        3.00    1.000
 5.59        5.00  100.000
4
 1.52       -0.50    1.000
 2.29        1.00    1.000
 3.09        3.00    1.000
 3.75        5.00  100.000
