Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.31       -0.50    1.000
 3.45        1.00    1.000
 5.06        3.00    1.000
 5.59        5.00  100.000
4
 1.03       -0.50    1.000
 2.17        1.00    1.000
 3.68        3.00    1.000
 3.73        5.00  100.000
