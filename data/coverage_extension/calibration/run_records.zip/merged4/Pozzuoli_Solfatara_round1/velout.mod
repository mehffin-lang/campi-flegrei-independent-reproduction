Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.17       -0.50    1.000
 3.04        1.00    1.000
 4.74        3.00    1.000
 5.48        5.00  100.000
4
 1.03       -0.50    1.000
 1.97        1.00    1.000
 3.35        3.00    1.000
 3.42        5.00  100.000
