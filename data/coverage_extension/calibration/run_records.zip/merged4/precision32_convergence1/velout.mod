Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.23       -0.50    1.000
 2.85        1.00    1.000
 4.49        3.00    1.000
 5.59        5.00  100.000
4
 1.48       -0.50    1.000
 2.27        1.00    1.000
 3.45        3.00    1.000
 3.75        5.00  100.000
