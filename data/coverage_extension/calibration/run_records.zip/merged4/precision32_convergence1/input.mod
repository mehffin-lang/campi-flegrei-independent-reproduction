Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.19       -0.50    1.000
 2.91        1.00    1.000
 4.50        3.00    1.000
 5.59        5.00  100.000
4
 1.44       -0.50    1.000
 2.26        1.00    1.000
 3.53        3.00    1.000
 3.75        5.00  100.000
