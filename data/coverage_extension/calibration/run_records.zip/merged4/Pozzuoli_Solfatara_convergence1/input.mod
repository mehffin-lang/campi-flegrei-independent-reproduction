Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.92       -0.50    1.000
 2.44        1.00    1.000
 4.29        3.00    1.000
 5.48        5.00  100.000
4
 1.41       -0.50    1.000
 2.16        1.00    1.000
 3.00        3.00    1.000
 3.42        5.00  100.000
