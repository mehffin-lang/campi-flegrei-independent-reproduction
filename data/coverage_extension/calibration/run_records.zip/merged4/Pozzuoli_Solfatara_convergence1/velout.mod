Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.96       -0.50    1.000
 2.39        1.00    1.000
 4.31        3.00    1.000
 5.48        5.00  100.000
4
 1.45       -0.50    1.000
 2.12        1.00    1.000
 2.96        3.00    1.000
 3.42        5.00  100.000
