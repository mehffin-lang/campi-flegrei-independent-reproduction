Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.20       -0.50    1.000
 2.66        1.00    1.000
 4.81        3.00    1.000
 5.59        5.00  100.000
4
 1.31       -0.50    1.000
 2.14        1.00    1.000
 3.54        3.00    1.000
 3.73        5.00  100.000
