Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.07       -0.50    1.000
 2.59        1.00    1.000
 4.60        3.00    1.000
 5.59        5.00  100.000
4
 1.47       -0.50    1.000
 2.16        1.00    1.000
 3.39        3.00    1.000
 3.73        5.00  100.000
