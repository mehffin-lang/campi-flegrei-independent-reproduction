Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.37       -0.50    1.000
 3.43        1.00    1.000
 5.05        3.00    1.000
 5.59        5.00  100.000
4
 1.03       -0.50    1.000
 2.18        1.00    1.000
 3.67        3.00    1.000
 3.71        5.00  100.000
