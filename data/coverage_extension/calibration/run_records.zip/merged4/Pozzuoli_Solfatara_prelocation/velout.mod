Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.30       -0.50    1.000
 3.41        1.00    1.000
 4.76        3.00    1.000
 5.48        5.00  100.000
4
 1.31       -0.50    1.000
 1.95        1.00    1.000
 2.91        3.00    1.000
 3.42        5.00  100.000
