Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 2.00       -0.50    1.000
 2.33        1.00    1.000
 4.32        3.00    1.000
 5.48        5.00  100.000
4
 1.50       -0.50    1.000
 2.11        1.00    1.000
 2.91        3.00    1.000
 3.42        5.00  100.000
