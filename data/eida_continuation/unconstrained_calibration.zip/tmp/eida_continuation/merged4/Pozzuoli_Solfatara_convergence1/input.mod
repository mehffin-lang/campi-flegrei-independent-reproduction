Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.33       -0.50    1.000
 2.67        1.00    1.000
 4.12        3.00    1.000
 5.48        5.00  100.000
4
 1.05       -0.50    1.000
 1.92        1.00    1.000
 3.78        3.00    1.000
 3.85        5.00  100.000
