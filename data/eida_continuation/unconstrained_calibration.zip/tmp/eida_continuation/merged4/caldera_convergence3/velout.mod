Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.56       -0.50    1.000
 2.77        1.00    1.000
 4.21        3.00    1.000
 5.59        5.00  100.000
4
 1.14       -0.50    1.000
 2.04        1.00    1.000
 3.87        3.00    1.000
 3.98        5.00  100.000
