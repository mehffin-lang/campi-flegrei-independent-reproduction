Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.54       -0.50    1.000
 3.26        1.00    1.000
 4.93        3.00    1.000
 5.48        5.00  100.000
4
 0.90       -0.50    1.000
 1.80        1.00    1.000
 3.86        3.00    1.000
 3.86        5.00  100.000
