Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.61       -0.50    1.000
 2.82        1.00    1.000
 4.36        3.00    1.000
 5.59        5.00  100.000
4
 1.16       -0.50    1.000
 2.03        1.00    1.000
 3.93        3.00    1.000
 3.98        5.00  100.000
