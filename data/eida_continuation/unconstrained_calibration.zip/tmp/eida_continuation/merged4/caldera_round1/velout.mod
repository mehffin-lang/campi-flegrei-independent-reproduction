Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.93       -0.50    1.000
 3.42        1.00    1.000
 4.92        3.00    1.000
 5.59        5.00  100.000
4
 0.99       -0.50    1.000
 1.90        1.00    1.000
 3.90        3.00    1.000
 3.93        5.00  100.000
