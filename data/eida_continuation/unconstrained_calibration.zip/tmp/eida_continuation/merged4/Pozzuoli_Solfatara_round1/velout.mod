Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.54       -0.50    1.000
 3.25        1.00    1.000
 4.94        3.00    1.000
 5.48        5.00  100.000
4
 0.90       -0.50    1.000
 1.79        1.00    1.000
 3.85        3.00    1.000
 3.85        5.00  100.000
