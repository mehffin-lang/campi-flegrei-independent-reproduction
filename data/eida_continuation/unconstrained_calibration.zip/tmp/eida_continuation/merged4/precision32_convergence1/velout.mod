Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.30       -0.50    1.000
 2.63        1.00    1.000
 4.03        3.00    1.000
 5.48        5.00  100.000
4
 1.04       -0.50    1.000
 1.91        1.00    1.000
 3.75        3.00    1.000
 3.86        5.00  100.000
