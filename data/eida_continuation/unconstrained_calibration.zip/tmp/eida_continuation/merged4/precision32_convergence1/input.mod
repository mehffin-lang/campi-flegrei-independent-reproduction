Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.32       -0.50    1.000
 2.66        1.00    1.000
 4.11        3.00    1.000
 5.48        5.00  100.000
4
 1.04       -0.50    1.000
 1.92        1.00    1.000
 3.78        3.00    1.000
 3.86        5.00  100.000
