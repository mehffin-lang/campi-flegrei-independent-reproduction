Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.25       -0.50    1.000
 2.56        1.00    1.000
 3.83        3.00    1.000
 5.48        5.00  100.000
4
 1.01       -0.50    1.000
 1.87        1.00    1.000
 3.60        3.00    1.000
 3.86        5.00  100.000
