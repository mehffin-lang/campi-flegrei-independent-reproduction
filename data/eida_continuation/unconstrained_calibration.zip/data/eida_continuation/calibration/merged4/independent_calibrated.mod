Independent fit; Tan-distributed Battaglia-attributed starting grid
4
 1.28       -0.50    1.000
 2.62        1.00    1.000
 3.98        3.00    1.000
 5.48        5.00  100.000
4
 1.04       -0.50    1.000
 1.90        1.00    1.000
 3.71        3.00    1.000
 3.85        5.00  100.000
