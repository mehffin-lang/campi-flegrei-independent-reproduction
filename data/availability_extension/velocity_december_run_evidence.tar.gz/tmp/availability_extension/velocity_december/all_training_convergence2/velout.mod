Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.12       -0.50   10.000
 1.61        0.50   10.000
 2.46        1.00   10.000
 5.30        3.00   10.000
4
 0.89       -0.50   10.000
 1.09        0.50   10.000
 1.88        1.00   10.000
 3.95        3.00   10.000
