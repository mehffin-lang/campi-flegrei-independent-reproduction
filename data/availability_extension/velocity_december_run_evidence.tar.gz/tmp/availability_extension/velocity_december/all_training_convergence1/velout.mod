Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.16       -0.50   10.000
 1.67        0.50   10.000
 2.47        1.00   10.000
 5.34        3.00   10.000
4
 0.92       -0.50   10.000
 1.10        0.50   10.000
 1.89        1.00   10.000
 3.91        3.00   10.000
