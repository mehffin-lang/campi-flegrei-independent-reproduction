Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.23       -0.50   10.000
 1.77        0.50   10.000
 2.49        1.00   10.000
 5.40        3.00   10.000
4
 0.93       -0.50   10.000
 1.13        0.50   10.000
 1.88        1.00   10.000
 3.82        3.00   10.000
