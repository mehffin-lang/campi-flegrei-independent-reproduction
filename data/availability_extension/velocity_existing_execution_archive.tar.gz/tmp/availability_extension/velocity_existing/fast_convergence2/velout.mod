Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.70       -0.50   10.000
 2.13        0.50   10.000
 3.03        1.00   10.000
 6.06        3.00   10.000
4
 1.12       -0.50   10.000
 1.25        0.50   10.000
 2.06        1.00   10.000
 3.54        3.00   10.000
