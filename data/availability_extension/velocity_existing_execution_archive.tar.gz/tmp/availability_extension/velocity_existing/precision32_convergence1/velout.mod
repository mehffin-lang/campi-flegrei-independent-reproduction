Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.59       -0.50   10.000
 1.94        0.50   10.000
 2.80        1.00   10.000
 5.51        3.00   10.000
4
 1.09       -0.50   10.000
 1.16        0.50   10.000
 1.90        1.00   10.000
 3.25        3.00   10.000
