Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.47       -0.50   10.000
 1.75        0.50   10.000
 2.64        1.00   10.000
 4.98        3.00   10.000
4
 0.92       -0.50   10.000
 1.07        0.50   10.000
 1.60        1.00   10.000
 2.86        3.00   10.000
