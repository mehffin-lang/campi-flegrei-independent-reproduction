Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.78       -0.50   10.000
 2.18        0.50   10.000
 3.12        1.00   10.000
 6.06        3.00   10.000
4
 1.10       -0.50   10.000
 1.19        0.50   10.000
 1.91        1.00   10.000
 3.48        3.00   10.000
