Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.75       -0.50   10.000
 2.16        0.50   10.000
 3.06        1.00   10.000
 6.06        3.00   10.000
4
 1.12       -0.50   10.000
 1.21        0.50   10.000
 2.00        1.00   10.000
 3.51        3.00   10.000
