Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.57       -0.50   10.000
 1.92        0.50   10.000
 2.77        1.00   10.000
 5.51        3.00   10.000
4
 1.11       -0.50   10.000
 1.18        0.50   10.000
 1.93        1.00   10.000
 3.29        3.00   10.000
