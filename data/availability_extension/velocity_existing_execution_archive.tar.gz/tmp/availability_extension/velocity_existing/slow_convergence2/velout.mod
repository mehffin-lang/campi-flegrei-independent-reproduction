Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.35       -0.50   10.000
 1.59        0.50   10.000
 2.53        1.00   10.000
 4.99        3.00   10.000
4
 0.80       -0.50   10.000
 1.26        0.50   10.000
 1.80        1.00   10.000
 2.95        3.00   10.000
