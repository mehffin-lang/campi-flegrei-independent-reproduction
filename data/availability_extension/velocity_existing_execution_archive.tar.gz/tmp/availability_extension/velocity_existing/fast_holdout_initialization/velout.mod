Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.87       -0.50   10.000
 2.20        0.50   10.000
 3.30        1.00   10.000
 6.05        3.00   10.000
4
 1.05       -0.50   10.000
 1.24        0.50   10.000
 1.85        1.00   10.000
 3.40        3.00   10.000
