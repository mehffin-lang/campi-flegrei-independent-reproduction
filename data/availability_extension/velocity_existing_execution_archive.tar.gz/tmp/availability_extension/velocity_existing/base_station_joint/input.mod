Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.64       -0.50   10.000
 1.99        0.50   10.000
 2.94        1.00   10.000
 5.51        3.00   10.000
4
 1.00       -0.50   10.000
 1.09        0.50   10.000
 1.69        1.00   10.000
 3.17        3.00   10.000
