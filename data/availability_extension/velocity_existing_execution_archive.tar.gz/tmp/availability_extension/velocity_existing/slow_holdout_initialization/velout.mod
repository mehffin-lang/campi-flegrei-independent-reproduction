Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.53       -0.50   10.000
 1.80        0.50   10.000
 2.70        1.00   10.000
 4.95        3.00   10.000
4
 0.86       -0.50   10.000
 1.01        0.50   10.000
 1.52        1.00   10.000
 2.78        3.00   10.000
