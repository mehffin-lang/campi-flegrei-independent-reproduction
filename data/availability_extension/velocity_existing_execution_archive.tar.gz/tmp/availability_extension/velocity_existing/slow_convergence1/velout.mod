Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.40       -0.50   10.000
 1.64        0.50   10.000
 2.54        1.00   10.000
 4.99        3.00   10.000
4
 0.81       -0.50   10.000
 1.21        0.50   10.000
 1.76        1.00   10.000
 2.92        3.00   10.000
