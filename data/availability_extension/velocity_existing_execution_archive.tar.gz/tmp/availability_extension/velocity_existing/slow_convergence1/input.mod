Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.44       -0.50   10.000
 1.69        0.50   10.000
 2.57        1.00   10.000
 4.99        3.00   10.000
4
 0.85       -0.50   10.000
 1.16        0.50   10.000
 1.71        1.00   10.000
 2.89        3.00   10.000
