Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.59       -0.50   10.000
 1.94        0.50   10.000
 2.80        1.00   10.000
 5.51        3.00   10.000
4
 1.08       -0.50   10.000
 1.16        0.50   10.000
 1.89        1.00   10.000
 3.25        3.00   10.000
