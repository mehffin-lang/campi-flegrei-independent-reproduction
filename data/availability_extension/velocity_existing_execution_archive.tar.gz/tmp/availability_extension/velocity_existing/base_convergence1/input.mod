Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.61       -0.50   10.000
 1.96        0.50   10.000
 2.85        1.00   10.000
 5.51        3.00   10.000
4
 1.04       -0.50   10.000
 1.13        0.50   10.000
 1.83        1.00   10.000
 3.21        3.00   10.000
