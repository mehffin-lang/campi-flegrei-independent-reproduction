Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.82       -0.50   10.000
 2.20        0.50   10.000
 3.21        1.00   10.000
 6.06        3.00   10.000
4
 1.04       -0.50   10.000
 1.17        0.50   10.000
 1.76        1.00   10.000
 3.45        3.00   10.000
