Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.23       -0.50   10.000
 1.76        0.50   10.000
 2.53        1.00   10.000
 5.40        3.00   10.000
4
 0.94       -0.50   10.000
 1.11        0.50   10.000
 1.89        1.00   10.000
 3.83        3.00   10.000
