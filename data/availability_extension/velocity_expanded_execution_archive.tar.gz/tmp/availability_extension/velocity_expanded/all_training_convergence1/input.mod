Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.26       -0.50   10.000
 1.79        0.50   10.000
 2.54        1.00   10.000
 5.42        3.00   10.000
4
 0.93       -0.50   10.000
 1.09        0.50   10.000
 1.89        1.00   10.000
 3.80        3.00   10.000
