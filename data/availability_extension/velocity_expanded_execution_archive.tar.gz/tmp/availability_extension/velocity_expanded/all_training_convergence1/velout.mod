Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.20       -0.50   10.000
 1.69        0.50   10.000
 2.49        1.00   10.000
 5.36        3.00   10.000
4
 0.92       -0.50   10.000
 1.12        0.50   10.000
 1.88        1.00   10.000
 3.90        3.00   10.000
