Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.34       -0.50   10.000
 1.96        0.50   10.000
 2.85        1.00   10.000
 5.48        3.00   10.000
4
 0.90       -0.50   10.000
 0.90        0.50   10.000
 1.70        1.00   10.000
 3.66        3.00   10.000
