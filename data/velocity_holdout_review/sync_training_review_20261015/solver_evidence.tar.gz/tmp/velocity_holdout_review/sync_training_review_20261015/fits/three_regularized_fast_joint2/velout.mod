Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.88       -0.50   10.000
 2.79        1.00   10.000
 5.73        3.00   10.000
3
 0.95       -0.50   10.000
 1.89        1.00   10.000
 3.35        3.00   10.000
