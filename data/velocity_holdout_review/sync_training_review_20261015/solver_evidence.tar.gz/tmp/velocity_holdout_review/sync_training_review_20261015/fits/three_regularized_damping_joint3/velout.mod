Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.79       -0.50   10.000
 2.93        1.00   10.000
 5.49        3.00   10.000
3
 1.04       -0.50   10.000
 1.76        1.00   10.000
 3.11        3.00   10.000
