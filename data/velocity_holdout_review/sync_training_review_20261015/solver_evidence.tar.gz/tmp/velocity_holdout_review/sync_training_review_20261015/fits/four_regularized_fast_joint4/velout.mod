Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.72       -0.50   10.000
 2.13        0.50   10.000
 2.64        1.00   10.000
 5.74        3.00   10.000
4
 0.93       -0.50   10.000
 1.06        0.50   10.000
 1.85        1.00   10.000
 3.39        3.00   10.000
