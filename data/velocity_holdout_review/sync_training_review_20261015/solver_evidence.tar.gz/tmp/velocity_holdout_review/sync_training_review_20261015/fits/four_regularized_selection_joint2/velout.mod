Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.66       -0.50   10.000
 1.93        0.50   10.000
 2.68        1.00   10.000
 5.43        3.00   10.000
4
 0.86       -0.50   10.000
 1.14        0.50   10.000
 1.82        1.00   10.000
 3.33        3.00   10.000
