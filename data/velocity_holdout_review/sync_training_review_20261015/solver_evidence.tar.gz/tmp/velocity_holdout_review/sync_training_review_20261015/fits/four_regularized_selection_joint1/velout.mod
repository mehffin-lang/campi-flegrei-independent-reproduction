Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.68       -0.50   10.000
 1.94        0.50   10.000
 2.76        1.00   10.000
 5.44        3.00   10.000
4
 0.86       -0.50   10.000
 1.14        0.50   10.000
 1.83        1.00   10.000
 3.28        3.00   10.000
