Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.85       -0.50   10.000
 2.65        1.00   10.000
 5.74        3.00   10.000
3
 0.94       -0.50   10.000
 1.86        1.00   10.000
 3.39        3.00   10.000
