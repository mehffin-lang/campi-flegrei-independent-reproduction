Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.78       -0.50   10.000
 2.12        0.50   10.000
 3.02        1.00   10.000
 5.74        3.00   10.000
4
 0.98       -0.50   10.000
 1.10        0.50   10.000
 1.80        1.00   10.000
 3.31        3.00   10.000
