Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.78       -0.50   10.000
 2.13        0.50   10.000
 2.89        1.00   10.000
 5.73        3.00   10.000
4
 0.94       -0.50   10.000
 1.08        0.50   10.000
 1.86        1.00   10.000
 3.33        3.00   10.000
