Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.64       -0.50   10.000
 1.92        0.50   10.000
 2.63        1.00   10.000
 5.42        3.00   10.000
4
 0.87       -0.50   10.000
 1.15        0.50   10.000
 1.81        1.00   10.000
 3.37        3.00   10.000
