Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.74       -0.50   10.000
 2.13        0.50   10.000
 2.69        1.00   10.000
 5.74        3.00   10.000
4
 0.92       -0.50   10.000
 1.06        0.50   10.000
 1.88        1.00   10.000
 3.37        3.00   10.000
