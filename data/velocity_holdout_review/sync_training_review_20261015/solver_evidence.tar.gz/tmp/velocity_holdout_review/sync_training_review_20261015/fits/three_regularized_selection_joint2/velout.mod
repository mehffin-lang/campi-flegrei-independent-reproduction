Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.67       -0.50   10.000
 2.68        1.00   10.000
 5.43        3.00   10.000
3
 0.90       -0.50   10.000
 1.86        1.00   10.000
 3.32        3.00   10.000
