Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.66       -0.50   10.000
 2.04        0.50   10.000
 2.63        1.00   10.000
 5.48        3.00   10.000
4
 0.90       -0.50   10.000
 1.03        0.50   10.000
 1.83        1.00   10.000
 3.21        3.00   10.000
