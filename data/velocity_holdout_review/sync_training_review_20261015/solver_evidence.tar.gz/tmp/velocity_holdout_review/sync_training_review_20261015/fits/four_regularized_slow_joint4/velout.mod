Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.52       -0.50   10.000
 1.90        0.50   10.000
 2.41        1.00   10.000
 5.19        3.00   10.000
4
 0.84       -0.50   10.000
 1.01        0.50   10.000
 1.72        1.00   10.000
 3.17        3.00   10.000
