Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.62       -0.50   10.000
 2.04        0.50   10.000
 2.52        1.00   10.000
 5.48        3.00   10.000
4
 0.90       -0.50   10.000
 1.03        0.50   10.000
 1.78        1.00   10.000
 3.27        3.00   10.000
