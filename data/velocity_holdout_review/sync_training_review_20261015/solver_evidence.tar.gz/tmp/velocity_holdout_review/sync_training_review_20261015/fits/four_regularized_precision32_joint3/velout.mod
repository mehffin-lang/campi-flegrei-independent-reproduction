Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.64       -0.50   10.000
 2.04        0.50   10.000
 2.58        1.00   10.000
 5.48        3.00   10.000
4
 0.90       -0.50   10.000
 1.02        0.50   10.000
 1.81        1.00   10.000
 3.23        3.00   10.000
