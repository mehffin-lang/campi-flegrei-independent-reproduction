Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.90       -0.50   10.000
 2.89        1.00   10.000
 5.73        3.00   10.000
3
 0.97       -0.50   10.000
 1.88        1.00   10.000
 3.33        3.00   10.000
