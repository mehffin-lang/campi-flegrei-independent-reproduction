Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.68       -0.50   10.000
 1.97        0.50   10.000
 2.88        1.00   10.000
 5.46        3.00   10.000
4
 0.91       -0.50   10.000
 1.12        0.50   10.000
 1.77        1.00   10.000
 3.23        3.00   10.000
