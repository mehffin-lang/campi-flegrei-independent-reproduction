Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.75       -0.50   10.000
 2.58        1.00   10.000
 5.48        3.00   10.000
3
 0.91       -0.50   10.000
 1.82        1.00   10.000
 3.25        3.00   10.000
