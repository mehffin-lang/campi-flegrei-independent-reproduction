Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.86       -0.50   10.000
 2.70        1.00   10.000
 5.74        3.00   10.000
3
 0.95       -0.50   10.000
 1.89        1.00   10.000
 3.37        3.00   10.000
