Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.63       -0.50   10.000
 1.91        0.50   10.000
 2.60        1.00   10.000
 5.41        3.00   10.000
4
 0.87       -0.50   10.000
 1.17        0.50   10.000
 1.79        1.00   10.000
 3.40        3.00   10.000
