Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.62       -0.50   10.000
 2.04        0.50   10.000
 2.53        1.00   10.000
 5.48        3.00   10.000
4
 0.90       -0.50   10.000
 1.02        0.50   10.000
 1.79        1.00   10.000
 3.26        3.00   10.000
