Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.58       -0.50   10.000
 1.91        0.50   10.000
 2.75        1.00   10.000
 5.19        3.00   10.000
4
 0.95       -0.50   10.000
 1.04        0.50   10.000
 1.69        1.00   10.000
 3.04        3.00   10.000
