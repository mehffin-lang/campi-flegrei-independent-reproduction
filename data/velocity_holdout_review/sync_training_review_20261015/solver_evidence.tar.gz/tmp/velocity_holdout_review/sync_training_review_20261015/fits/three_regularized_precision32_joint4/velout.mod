Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.73       -0.50   10.000
 2.54        1.00   10.000
 5.48        3.00   10.000
3
 0.91       -0.50   10.000
 1.79        1.00   10.000
 3.27        3.00   10.000
