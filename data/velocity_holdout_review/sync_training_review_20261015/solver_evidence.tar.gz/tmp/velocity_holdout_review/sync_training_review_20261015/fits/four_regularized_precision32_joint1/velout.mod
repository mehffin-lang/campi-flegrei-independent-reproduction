Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.68       -0.50   10.000
 2.03        0.50   10.000
 2.75        1.00   10.000
 5.47        3.00   10.000
4
 0.93       -0.50   10.000
 1.05        0.50   10.000
 1.81        1.00   10.000
 3.19        3.00   10.000
