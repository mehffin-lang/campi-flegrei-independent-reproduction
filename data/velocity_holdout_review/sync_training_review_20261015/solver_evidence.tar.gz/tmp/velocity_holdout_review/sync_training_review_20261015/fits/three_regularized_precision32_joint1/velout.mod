Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.79       -0.50   10.000
 2.76        1.00   10.000
 5.47        3.00   10.000
3
 0.95       -0.50   10.000
 1.82        1.00   10.000
 3.20        3.00   10.000
