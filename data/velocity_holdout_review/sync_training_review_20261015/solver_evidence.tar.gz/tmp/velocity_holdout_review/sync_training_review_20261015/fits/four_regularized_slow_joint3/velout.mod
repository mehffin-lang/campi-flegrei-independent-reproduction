Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.54       -0.50   10.000
 1.91        0.50   10.000
 2.45        1.00   10.000
 5.19        3.00   10.000
4
 0.85       -0.50   10.000
 1.01        0.50   10.000
 1.74        1.00   10.000
 3.14        3.00   10.000
