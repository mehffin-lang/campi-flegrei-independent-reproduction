Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.58       -0.50   10.000
 1.91        0.50   10.000
 2.61        1.00   10.000
 5.19        3.00   10.000
4
 0.90       -0.50   10.000
 1.02        0.50   10.000
 1.75        1.00   10.000
 3.08        3.00   10.000
