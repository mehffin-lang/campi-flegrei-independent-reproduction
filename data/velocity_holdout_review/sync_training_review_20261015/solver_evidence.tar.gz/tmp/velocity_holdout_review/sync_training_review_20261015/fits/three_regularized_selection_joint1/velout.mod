Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.71       -0.50   10.000
 2.78        1.00   10.000
 5.44        3.00   10.000
3
 0.93       -0.50   10.000
 1.85        1.00   10.000
 3.27        3.00   10.000
