Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.90       -0.50   10.000
 3.02        1.00   10.000
 5.74        3.00   10.000
3
 1.02       -0.50   10.000
 1.82        1.00   10.000
 3.31        3.00   10.000
