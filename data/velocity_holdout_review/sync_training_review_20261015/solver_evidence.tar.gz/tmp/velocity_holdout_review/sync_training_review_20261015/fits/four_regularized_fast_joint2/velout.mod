Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.76       -0.50   10.000
 2.13        0.50   10.000
 2.78        1.00   10.000
 5.73        3.00   10.000
4
 0.92       -0.50   10.000
 1.07        0.50   10.000
 1.88        1.00   10.000
 3.35        3.00   10.000
