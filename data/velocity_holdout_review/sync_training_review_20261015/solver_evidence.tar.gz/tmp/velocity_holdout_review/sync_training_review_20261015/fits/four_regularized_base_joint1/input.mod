Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.68       -0.50   10.000
 2.02        0.50   10.000
 2.88        1.00   10.000
 5.47        3.00   10.000
4
 0.97       -0.50   10.000
 1.07        0.50   10.000
 1.75        1.00   10.000
 3.17        3.00   10.000
