Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.74       -0.50   10.000
 2.91        1.00   10.000
 5.46        3.00   10.000
3
 0.99       -0.50   10.000
 1.76        1.00   10.000
 3.22        3.00   10.000
