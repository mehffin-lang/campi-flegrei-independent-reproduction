Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.56       -0.50   10.000
 1.91        0.50   10.000
 2.52        1.00   10.000
 5.19        3.00   10.000
4
 0.87       -0.50   10.000
 1.01        0.50   10.000
 1.75        1.00   10.000
 3.11        3.00   10.000
