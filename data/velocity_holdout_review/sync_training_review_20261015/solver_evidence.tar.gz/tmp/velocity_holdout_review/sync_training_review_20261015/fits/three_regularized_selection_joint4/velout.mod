Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.63       -0.50   10.000
 2.60        1.00   10.000
 5.41        3.00   10.000
3
 0.89       -0.50   10.000
 1.83        1.00   10.000
 3.39        3.00   10.000
