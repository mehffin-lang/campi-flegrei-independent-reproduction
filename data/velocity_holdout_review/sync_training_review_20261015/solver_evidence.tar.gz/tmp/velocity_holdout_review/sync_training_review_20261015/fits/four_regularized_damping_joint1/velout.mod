Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.69       -0.50   10.000
 2.00        0.50   10.000
 2.96        1.00   10.000
 5.49        3.00   10.000
4
 0.98       -0.50   10.000
 1.13        0.50   10.000
 1.75        1.00   10.000
 3.11        3.00   10.000
