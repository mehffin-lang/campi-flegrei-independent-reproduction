Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.79       -0.50   10.000
 2.86        1.00   10.000
 5.74        3.00   10.000
3
 0.96       -0.50   10.000
 1.92        1.00   10.000
 3.35        3.00   10.000
