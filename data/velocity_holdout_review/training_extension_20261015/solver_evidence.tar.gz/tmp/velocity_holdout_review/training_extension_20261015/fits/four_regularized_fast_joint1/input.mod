Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.78       -0.50   10.000
 2.10        0.50   10.000
 3.05        1.00   10.000
 5.75        3.00   10.000
4
 0.96       -0.50   10.000
 1.15        0.50   10.000
 1.82        1.00   10.000
 3.30        3.00   10.000
