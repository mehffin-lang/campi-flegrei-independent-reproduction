Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.60       -0.50   10.000
 2.56        1.00   10.000
 5.40        3.00   10.000
3
 0.87       -0.50   10.000
 1.81        1.00   10.000
 3.45        3.00   10.000
