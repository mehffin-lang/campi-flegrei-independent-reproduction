Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.71       -0.50   10.000
 1.96        0.50   10.000
 2.81        1.00   10.000
 5.46        3.00   10.000
4
 0.87       -0.50   10.000
 1.16        0.50   10.000
 1.84        1.00   10.000
 3.19        3.00   10.000
