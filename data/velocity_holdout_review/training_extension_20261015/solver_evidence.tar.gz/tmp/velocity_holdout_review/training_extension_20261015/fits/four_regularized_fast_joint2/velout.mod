Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.78       -0.50   10.000
 2.05        0.50   10.000
 2.86        1.00   10.000
 5.74        3.00   10.000
4
 0.87       -0.50   10.000
 1.23        0.50   10.000
 1.89        1.00   10.000
 3.34        3.00   10.000
