Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.78       -0.50   10.000
 2.92        1.00   10.000
 5.47        3.00   10.000
3
 1.00       -0.50   10.000
 1.78        1.00   10.000
 3.17        3.00   10.000
