Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.56       -0.50   10.000
 1.74        0.50   10.000
 2.55        1.00   10.000
 5.18        3.00   10.000
4
 0.80       -0.50   10.000
 1.25        0.50   10.000
 1.76        1.00   10.000
 3.17        3.00   10.000
