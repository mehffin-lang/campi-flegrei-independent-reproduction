Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.76       -0.50   10.000
 2.01        0.50   10.000
 2.80        1.00   10.000
 5.74        3.00   10.000
4
 0.86       -0.50   10.000
 1.28        0.50   10.000
 1.88        1.00   10.000
 3.37        3.00   10.000
