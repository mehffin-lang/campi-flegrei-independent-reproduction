Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.58       -0.50   10.000
 1.76        0.50   10.000
 2.57        1.00   10.000
 5.18        3.00   10.000
4
 0.80       -0.50   10.000
 1.23        0.50   10.000
 1.78        1.00   10.000
 3.15        3.00   10.000
