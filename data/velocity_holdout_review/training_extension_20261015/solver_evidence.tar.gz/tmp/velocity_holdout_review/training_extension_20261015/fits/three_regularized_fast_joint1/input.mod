Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.88       -0.50   10.000
 3.05        1.00   10.000
 5.75        3.00   10.000
3
 1.02       -0.50   10.000
 1.84        1.00   10.000
 3.30        3.00   10.000
