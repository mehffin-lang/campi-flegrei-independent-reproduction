Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.72       -0.50   10.000
 2.77        1.00   10.000
 5.74        3.00   10.000
3
 0.96       -0.50   10.000
 1.89        1.00   10.000
 3.39        3.00   10.000
