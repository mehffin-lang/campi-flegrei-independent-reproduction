Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.62       -0.50   10.000
 1.84        0.50   10.000
 2.68        1.00   10.000
 5.18        3.00   10.000
4
 0.84       -0.50   10.000
 1.15        0.50   10.000
 1.79        1.00   10.000
 3.08        3.00   10.000
