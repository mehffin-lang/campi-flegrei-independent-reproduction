Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.70       -0.50   10.000
 1.89        0.50   10.000
 2.76        1.00   10.000
 5.43        3.00   10.000
4
 0.85       -0.50   10.000
 1.18        0.50   10.000
 1.81        1.00   10.000
 3.29        3.00   10.000
