Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.69       -0.50   10.000
 1.85        0.50   10.000
 2.68        1.00   10.000
 5.41        3.00   10.000
4
 0.84       -0.50   10.000
 1.20        0.50   10.000
 1.80        1.00   10.000
 3.36        3.00   10.000
