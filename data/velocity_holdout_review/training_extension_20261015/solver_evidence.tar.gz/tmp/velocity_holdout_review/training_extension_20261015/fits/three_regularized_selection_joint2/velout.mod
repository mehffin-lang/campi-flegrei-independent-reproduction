Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.65       -0.50   10.000
 2.65        1.00   10.000
 5.42        3.00   10.000
3
 0.89       -0.50   10.000
 1.85        1.00   10.000
 3.36        3.00   10.000
