Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.73       -0.50   10.000
 1.98        0.50   10.000
 2.77        1.00   10.000
 5.74        3.00   10.000
4
 0.85       -0.50   10.000
 1.32        0.50   10.000
 1.86        1.00   10.000
 3.40        3.00   10.000
