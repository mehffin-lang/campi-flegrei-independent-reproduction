Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.68       -0.50   10.000
 1.82        0.50   10.000
 2.63        1.00   10.000
 5.39        3.00   10.000
4
 0.84       -0.50   10.000
 1.21        0.50   10.000
 1.78        1.00   10.000
 3.41        3.00   10.000
