Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.78       -0.50   10.000
 2.10        0.50   10.000
 3.15        1.00   10.000
 5.78        3.00   10.000
4
 1.00       -0.50   10.000
 1.18        0.50   10.000
 1.77        1.00   10.000
 3.24        3.00   10.000
