Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.69       -0.50   10.000
 1.95        0.50   10.000
 2.88        1.00   10.000
 5.45        3.00   10.000
4
 0.90       -0.50   10.000
 1.15        0.50   10.000
 1.76        1.00   10.000
 3.23        3.00   10.000
