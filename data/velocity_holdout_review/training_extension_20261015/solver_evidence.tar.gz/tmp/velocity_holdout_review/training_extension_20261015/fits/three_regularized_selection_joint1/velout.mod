Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.69       -0.50   10.000
 2.76        1.00   10.000
 5.43        3.00   10.000
3
 0.92       -0.50   10.000
 1.85        1.00   10.000
 3.29        3.00   10.000
