Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.67       -0.50   10.000
 2.70        1.00   10.000
 5.46        3.00   10.000
3
 0.95       -0.50   10.000
 1.85        1.00   10.000
 3.26        3.00   10.000
