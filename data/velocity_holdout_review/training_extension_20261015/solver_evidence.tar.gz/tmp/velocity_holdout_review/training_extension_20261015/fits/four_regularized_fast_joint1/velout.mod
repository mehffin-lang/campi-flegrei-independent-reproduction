Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.79       -0.50   10.000
 2.08        0.50   10.000
 2.94        1.00   10.000
 5.74        3.00   10.000
4
 0.90       -0.50   10.000
 1.19        0.50   10.000
 1.88        1.00   10.000
 3.32        3.00   10.000
