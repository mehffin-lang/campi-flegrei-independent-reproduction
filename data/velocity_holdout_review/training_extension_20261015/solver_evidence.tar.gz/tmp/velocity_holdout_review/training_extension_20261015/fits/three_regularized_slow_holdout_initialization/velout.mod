Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.71       -0.50   10.000
 2.85        1.00   10.000
 5.22        3.00   10.000
3
 0.96       -0.50   10.000
 1.60        1.00   10.000
 2.94        3.00   10.000
