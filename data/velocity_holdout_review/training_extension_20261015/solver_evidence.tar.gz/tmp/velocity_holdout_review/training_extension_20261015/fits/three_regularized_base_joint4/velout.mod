Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.65       -0.50   10.000
 2.68        1.00   10.000
 5.46        3.00   10.000
3
 0.95       -0.50   10.000
 1.84        1.00   10.000
 3.28        3.00   10.000
