Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.61       -0.50   10.000
 1.88        0.50   10.000
 2.78        1.00   10.000
 5.19        3.00   10.000
4
 0.92       -0.50   10.000
 1.10        0.50   10.000
 1.72        1.00   10.000
 3.04        3.00   10.000
