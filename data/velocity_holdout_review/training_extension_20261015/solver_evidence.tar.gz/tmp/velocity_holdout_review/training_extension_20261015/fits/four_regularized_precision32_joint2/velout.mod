Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.70       -0.50   10.000
 1.93        0.50   10.000
 2.73        1.00   10.000
 5.46        3.00   10.000
4
 0.84       -0.50   10.000
 1.19        0.50   10.000
 1.85        1.00   10.000
 3.22        3.00   10.000
