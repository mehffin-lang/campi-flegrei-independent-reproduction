Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.60       -0.50   10.000
 1.80        0.50   10.000
 2.61        1.00   10.000
 5.18        3.00   10.000
4
 0.81       -0.50   10.000
 1.19        0.50   10.000
 1.80        1.00   10.000
 3.11        3.00   10.000
