Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.68       -0.50   10.000
 1.91        0.50   10.000
 2.68        1.00   10.000
 5.46        3.00   10.000
4
 0.83       -0.50   10.000
 1.22        0.50   10.000
 1.83        1.00   10.000
 3.25        3.00   10.000
