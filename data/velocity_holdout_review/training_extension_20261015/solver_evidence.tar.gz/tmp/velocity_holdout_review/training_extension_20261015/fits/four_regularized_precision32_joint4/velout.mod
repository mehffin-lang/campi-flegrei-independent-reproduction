Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.66       -0.50   10.000
 1.89        0.50   10.000
 2.64        1.00   10.000
 5.46        3.00   10.000
4
 0.83       -0.50   10.000
 1.24        0.50   10.000
 1.82        1.00   10.000
 3.28        3.00   10.000
