Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.83       -0.50   10.000
 2.94        1.00   10.000
 5.74        3.00   10.000
3
 0.98       -0.50   10.000
 1.90        1.00   10.000
 3.34        3.00   10.000
