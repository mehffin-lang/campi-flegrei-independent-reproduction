Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.59       -0.50   10.000
 1.80        0.50   10.000
 2.60        1.00   10.000
 5.21        3.00   10.000
4
 0.81       -0.50   10.000
 1.19        0.50   10.000
 1.79        1.00   10.000
 3.12        3.00   10.000
