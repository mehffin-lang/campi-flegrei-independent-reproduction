Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.66       -0.50   10.000
 1.91        0.50   10.000
 2.66        1.00   10.000
 5.47        3.00   10.000
4
 0.84       -0.50   10.000
 1.26        0.50   10.000
 1.80        1.00   10.000
 3.29        3.00   10.000
