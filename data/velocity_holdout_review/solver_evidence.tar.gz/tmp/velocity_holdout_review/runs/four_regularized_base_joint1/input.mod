Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.70       -0.50   10.000
 1.99        0.50   10.000
 2.92        1.00   10.000
 5.47        3.00   10.000
4
 0.94       -0.50   10.000
 1.13        0.50   10.000
 1.77        1.00   10.000
 3.17        3.00   10.000
