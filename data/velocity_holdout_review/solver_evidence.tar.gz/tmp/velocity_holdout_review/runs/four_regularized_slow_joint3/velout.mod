Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.57       -0.50   10.000
 1.77        0.50   10.000
 2.56        1.00   10.000
 5.21        3.00   10.000
4
 0.80       -0.50   10.000
 1.23        0.50   10.000
 1.77        1.00   10.000
 3.15        3.00   10.000
