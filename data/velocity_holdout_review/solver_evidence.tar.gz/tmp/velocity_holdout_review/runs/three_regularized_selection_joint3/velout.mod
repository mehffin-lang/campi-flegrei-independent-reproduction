Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.61       -0.50   10.000
 2.61        1.00   10.000
 5.43        3.00   10.000
3
 0.88       -0.50   10.000
 1.83        1.00   10.000
 3.41        3.00   10.000
