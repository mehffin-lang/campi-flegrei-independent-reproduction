Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.69       -0.50   10.000
 1.86        0.50   10.000
 2.68        1.00   10.000
 5.43        3.00   10.000
4
 0.85       -0.50   10.000
 1.20        0.50   10.000
 1.79        1.00   10.000
 3.37        3.00   10.000
