Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.75       -0.50   10.000
 2.01        0.50   10.000
 2.83        1.00   10.000
 5.74        3.00   10.000
4
 0.86       -0.50   10.000
 1.29        0.50   10.000
 1.86        1.00   10.000
 3.40        3.00   10.000
