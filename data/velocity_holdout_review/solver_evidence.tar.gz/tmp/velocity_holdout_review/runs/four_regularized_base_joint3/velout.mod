Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.67       -0.50   10.000
 1.91        0.50   10.000
 2.68        1.00   10.000
 5.48        3.00   10.000
4
 0.83       -0.50   10.000
 1.24        0.50   10.000
 1.83        1.00   10.000
 3.27        3.00   10.000
