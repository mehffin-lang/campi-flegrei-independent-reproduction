Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.77       -0.50   10.000
 2.04        0.50   10.000
 2.87        1.00   10.000
 5.74        3.00   10.000
4
 0.87       -0.50   10.000
 1.24        0.50   10.000
 1.88        1.00   10.000
 3.37        3.00   10.000
