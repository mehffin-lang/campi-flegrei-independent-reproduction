Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.69       -0.50   10.000
 1.99        0.50   10.000
 2.94        1.00   10.000
 5.49        3.00   10.000
4
 0.96       -0.50   10.000
 1.17        0.50   10.000
 1.78        1.00   10.000
 3.12        3.00   10.000
