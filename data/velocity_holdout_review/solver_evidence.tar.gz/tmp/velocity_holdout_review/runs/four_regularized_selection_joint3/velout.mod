Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.67       -0.50   10.000
 1.84        0.50   10.000
 2.63        1.00   10.000
 5.42        3.00   10.000
4
 0.85       -0.50   10.000
 1.21        0.50   10.000
 1.77        1.00   10.000
 3.42        3.00   10.000
