Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.75       -0.50   10.000
 2.81        1.00   10.000
 5.74        3.00   10.000
3
 0.95       -0.50   10.000
 1.91        1.00   10.000
 3.39        3.00   10.000
