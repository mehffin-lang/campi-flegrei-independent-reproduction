Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.56       -0.50   10.000
 1.75        0.50   10.000
 2.54        1.00   10.000
 5.21        3.00   10.000
4
 0.80       -0.50   10.000
 1.26        0.50   10.000
 1.75        1.00   10.000
 3.17        3.00   10.000
