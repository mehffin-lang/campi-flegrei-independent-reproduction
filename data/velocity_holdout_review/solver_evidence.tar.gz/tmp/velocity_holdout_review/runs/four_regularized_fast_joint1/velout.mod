Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.79       -0.50   10.000
 2.07        0.50   10.000
 2.95        1.00   10.000
 5.74        3.00   10.000
4
 0.90       -0.50   10.000
 1.20        0.50   10.000
 1.87        1.00   10.000
 3.34        3.00   10.000
