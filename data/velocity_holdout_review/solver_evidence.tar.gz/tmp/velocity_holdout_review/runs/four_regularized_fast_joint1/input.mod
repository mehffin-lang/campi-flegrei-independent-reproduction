Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.78       -0.50   10.000
 2.10        0.50   10.000
 3.06        1.00   10.000
 5.75        3.00   10.000
4
 0.96       -0.50   10.000
 1.16        0.50   10.000
 1.82        1.00   10.000
 3.31        3.00   10.000
