Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.73       -0.50   10.000
 1.99        0.50   10.000
 2.81        1.00   10.000
 5.74        3.00   10.000
4
 0.86       -0.50   10.000
 1.32        0.50   10.000
 1.85        1.00   10.000
 3.42        3.00   10.000
