Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.70       -0.50   10.000
 1.94        0.50   10.000
 2.74        1.00   10.000
 5.47        3.00   10.000
4
 0.85       -0.50   10.000
 1.21        0.50   10.000
 1.83        1.00   10.000
 3.23        3.00   10.000
