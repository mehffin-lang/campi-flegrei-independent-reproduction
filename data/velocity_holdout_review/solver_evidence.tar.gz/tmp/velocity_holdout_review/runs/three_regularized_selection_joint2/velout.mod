Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.64       -0.50   10.000
 2.66        1.00   10.000
 5.44        3.00   10.000
3
 0.89       -0.50   10.000
 1.85        1.00   10.000
 3.37        3.00   10.000
