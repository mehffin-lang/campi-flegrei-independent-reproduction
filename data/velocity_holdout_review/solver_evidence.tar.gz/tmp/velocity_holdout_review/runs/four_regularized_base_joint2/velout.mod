Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.69       -0.50   10.000
 1.93        0.50   10.000
 2.73        1.00   10.000
 5.48        3.00   10.000
4
 0.84       -0.50   10.000
 1.21        0.50   10.000
 1.84        1.00   10.000
 3.24        3.00   10.000
