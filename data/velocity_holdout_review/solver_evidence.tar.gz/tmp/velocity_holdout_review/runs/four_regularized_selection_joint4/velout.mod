Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.66       -0.50   10.000
 1.82        0.50   10.000
 2.60        1.00   10.000
 5.41        3.00   10.000
4
 0.84       -0.50   10.000
 1.22        0.50   10.000
 1.76        1.00   10.000
 3.45        3.00   10.000
