Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.65       -0.50   10.000
 1.89        0.50   10.000
 2.65        1.00   10.000
 5.48        3.00   10.000
4
 0.83       -0.50   10.000
 1.26        0.50   10.000
 1.81        1.00   10.000
 3.29        3.00   10.000
