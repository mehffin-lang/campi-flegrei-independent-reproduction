Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.75       -0.50   10.000
 2.81        1.00   10.000
 5.47        3.00   10.000
3
 0.96       -0.50   10.000
 1.85        1.00   10.000
 3.20        3.00   10.000
