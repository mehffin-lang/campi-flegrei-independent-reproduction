Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.68       -0.50   10.000
 1.92        0.50   10.000
 2.69        1.00   10.000
 5.47        3.00   10.000
4
 0.84       -0.50   10.000
 1.24        0.50   10.000
 1.82        1.00   10.000
 3.26        3.00   10.000
