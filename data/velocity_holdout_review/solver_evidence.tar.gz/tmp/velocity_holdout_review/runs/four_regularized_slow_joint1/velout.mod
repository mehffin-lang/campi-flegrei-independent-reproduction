Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.61       -0.50   10.000
 1.84        0.50   10.000
 2.67        1.00   10.000
 5.20        3.00   10.000
4
 0.84       -0.50   10.000
 1.15        0.50   10.000
 1.78        1.00   10.000
 3.09        3.00   10.000
