Independent alternative-profile VELEST fit; not Battaglia/Tan model
4
 1.60       -0.50   10.000
 1.88        0.50   10.000
 2.78        1.00   10.000
 5.20        3.00   10.000
4
 0.92       -0.50   10.000
 1.10        0.50   10.000
 1.71        1.00   10.000
 3.04        3.00   10.000
