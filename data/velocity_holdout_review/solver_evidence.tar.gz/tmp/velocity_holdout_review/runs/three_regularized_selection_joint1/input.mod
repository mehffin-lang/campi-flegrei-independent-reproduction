Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.72       -0.50   10.000
 2.90        1.00   10.000
 5.46        3.00   10.000
3
 0.98       -0.50   10.000
 1.76        1.00   10.000
 3.24        3.00   10.000
