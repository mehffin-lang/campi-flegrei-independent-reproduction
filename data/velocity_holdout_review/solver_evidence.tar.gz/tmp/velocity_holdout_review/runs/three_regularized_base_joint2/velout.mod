Independent alternative-profile VELEST fit; not Battaglia/Tan model
3
 1.70       -0.50   10.000
 2.74        1.00   10.000
 5.48        3.00   10.000
3
 0.95       -0.50   10.000
 1.87        1.00   10.000
 3.23        3.00   10.000
